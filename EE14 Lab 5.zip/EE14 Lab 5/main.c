#include "stm32l476xx.h"
#include "SysTick.h"
#include "LED.h"
#include "LCD.h"

void System_Clock_Init(void){
	
	RCC->CR |= RCC_CR_MSION; 
	
	// Select MSI as the clock source of System Clock
	RCC->CFGR &= ~RCC_CFGR_SW; 
	
	// Wait until MSI is ready
	while ((RCC->CR & RCC_CR_MSIRDY) == 0); 	
	
	// MSIRANGE can be modified when MSI is OFF (MSION=0) or when MSI is ready (MSIRDY=1). 
	RCC->CR &= ~RCC_CR_MSIRANGE; 
	RCC->CR |= RCC_CR_MSIRANGE_7;  // Select MSI 8 MHz	
 
	// The MSIRGSEL bit in RCC-CR select which MSIRANGE is used. 
	// If MSIRGSEL is 0, the MSIRANGE in RCC_CSR is used to select the MSI clock range.  (This is the default)
	// If MSIRGSEL is 1, the MSIRANGE in RCC_CR is used. 
	RCC->CR |= RCC_CR_MSIRGSEL; 
	
	// Enable MSI and wait until it's ready	
	while ((RCC->CR & RCC_CR_MSIRDY) == 0); 		
}

void delay_old(void) {
	// Delay loop
	int i;
	for (i = 0; i < 1350000; i++);
}

int main(void){
	//volotile variable makes compiler check its value every time its used
	volatile uint32_t time;
	//initializations
	System_Clock_Init();
	SysTick_Initialize(1000); //systick system interupt every 1ms
	LCD_Initialization();
	//initialize GPIOA as input for joystick
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN; //Enable clock to GPIOA
	GPIOA->MODER &= ~3UL; //Set mode as intput (00)
	//start at time = 0 and display
	time = 0;
	LCD_ConvTime(time);
	while(1) {
		//wait for input, if input changes to 1...
		if((GPIOA->IDR & 0x1) == 0x1) {
			//wait for button to be released
			while((GPIOA->IDR & 0x1) != 0x00);
			//start counting up and display the time after each count up
			while (1) {
				//should increment time by 1ms every 1ms
				time+=24; //increment time in ms by 1
				delay(1); //delay 1ms
				LCD_ConvTime(time);
				//if buttone is pressed again, exit counting loop
				if((GPIOA->IDR & 0x1) == 0x1) {
					while((GPIOA->IDR & 0x1) != 0x00); //need to wait for button to be released to prevent input being read over and over again
					break;
				}
			}
		}
	}
}
	//System Clock Initialization
	//System_Clock_Init();
	//LED Initialization
	//LED_Init();
	//SysTick Initialization
	//SysTick_Initialize(1000); //set the interupt time to 1ms
	//while (!(RCC->BDCR & RCC_BDCR_LSERDY)); // wait for LSE to be ready
	//RCC->CR |= RCC_CR_MSIPLLEN;
	//Red_LED_On();
	//while(1) {
		//delay of 1Sec
		//delay(1000); //1000ms = 1s
		//delay_old();
		//LED Toggle
		//Red_LED_Toggle();
	//}
